from setuptools import setup

setup(name='likpyexp',
      version='0.1',
      description='It has input code and output of 20 Python Experiments',
      author='Likhith Reddy',
      packages=['likpyexp'],
      zip_safe=False)
