# likpyexp
You can download this module using:
https://pypi.org/project/likpyexp/
with 
"pip install likpyexp"


This module consisit of 20 Python Experiments:

1. write a program to demonstrate different number data types in python
2. write a program to perform different Arithmetic Operations on numbers in python
3. write a program to create, concatenate and print a string and accessing sub-string from a given string
4. write a python script to print the current date in the following format "Sun May 29 02:26:23 IST 2017"
5. write a program to create, append and remove lists in python
6. write a program to demonstrate working with tuples in python
7. write a program to demonstrate working with dictionaries in python
8. write a program to find largest of three numbers
9. write a python program to convert temperatures to and from celsius,fahrenheit. [formula: c/5 = f-32/9] 
10. write a python program to conduct the following pattern, using a nested for loop
11. write a python script that prints prime numbers less than 20
12. write a python program to find factorial of a number using Recursion
13. write a program that accepts the lengths of three sides of a triangle as inputs. The program output should indicate whether or not the triangle is a right triangle (Recall from the Pythagorean Theorem that in a right triangle, the square of one side equals the sum of the squares of other two sides)
14. write a python program to define a module to find Fibnacci Numbers and import the module to another program
15. write a python program to define a module and import a specific function in that module to another program
16. write a script named copyfile.py this script prompt the user for the names of two text files. The contents of the first file should be input and written to second file
17. write a program that inputs a text file.The program should print all of the unique words in the file in alphabetical order
18. write a python class to convert an integer to a roman numeral.
19. write a python class to implement pow(x, n).
20. write a python class to reverse a string word by word



THANK YOU :>
GITHUB : https://github.com/likhith1409
